package ca.uvic.seng330.assn3.controllers;

import ca.uvic.seng330.assn3.models.DeviceModel;
import ca.uvic.seng330.assn3.models.SmartPlugModel;
import ca.uvic.seng330.assn3.models.Status;

public class SmartPlugCtr extends DeviceCtr {

  private SmartPlugModel smartplugModel;

  public SmartPlugCtr(HubCtr hub) {
    super(hub);
    smartplugModel = new SmartPlugModel();
  }

  public void toggle() {

    if (smartplugModel.getonStatus()) {
      smartplugModel.setonStatus(false);
    } else {
      smartplugModel.setonStatus(true);
    }

  }

  public SmartPlugModel getModel() {
    return smartplugModel;
  }
}