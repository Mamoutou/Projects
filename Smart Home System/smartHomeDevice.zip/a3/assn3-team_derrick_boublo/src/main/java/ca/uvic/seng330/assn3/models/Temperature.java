package ca.uvic.seng330.assn3.models;

public class Temperature {
  private double temp;
  private Unit unit;
  private static final int MAXTEMP = 150;

  public class TemperatureOutofBoundsException extends Exception {

    public TemperatureOutofBoundsException(String errorMessage) {
      super(errorMessage);
    }

  }

  public enum Unit { CELSIUS, FAHRENHEIT }

  public Temperature(double temp, Unit unit) throws TemperatureOutofBoundsException {
    if (temp > MAXTEMP) {
      throw new TemperatureOutofBoundsException("Temperature too high");
    }
    this.temp = temp;
    this.unit = unit;
  }

  public Temperature() {
    this.temp = 20.0; // Room temp
    this.unit  = Unit.CELSIUS;
  }

  public Temperature(Temperature t) {
    this.temp = t.temp;
    this.unit = t.unit;
  }

  public Unit getUnit() {
    return unit;
  }

  public double getTempNum() {
    return temp;
  }

  void setTemp(double temp, Unit unit) throws TemperatureOutofBoundsException {
    if (temp > MAXTEMP) {
      throw new TemperatureOutofBoundsException("Temperature too high");
    }
    this.temp = temp;
    this.unit = unit;
  }


}