package ca.uvic.seng330.assn3.models;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.Reader;

import java.util.UUID;

import org.json.JSONObject;
import org.json.JSONTokener;

public class SmartPlugModel extends DeviceModel {
  private boolean onStatus;

  public SmartPlugModel() {
    super();
  }

  public SmartPlugModel(UUID uuid) {
    fileToData(uuid);
  }

  public boolean getonStatus() {
    return onStatus;
  }

  public void setonStatus(boolean onStatus) {
    this.onStatus = onStatus;
  }
  
  public void dataToFile() {
    String filename = "smartplugData" + this.getIdentifier().toString()
        + ".json";
    JSONObject data = new JSONObject();
    data.put("uuid", this.getIdentifier().toString());
    data.put("status", this.getStatus().name());
    data.put("onStatus", onStatus);

    try {
      PrintWriter file = new PrintWriter(new FileOutputStream(filename, false));
      file.write(data.toString());
      file.close();
    } catch (FileNotFoundException e) {
      System.out.println(e);
    }
  }
  

  void fileToData(UUID uuid) {
    String filename = "smartplugData" + uuid.toString() + ".json";

    try {
      Reader reader = new FileReader(filename);
      JSONTokener tokenizer = new JSONTokener(reader);
      JSONObject data = new JSONObject(tokenizer);

      this.setIdentifier(UUID.fromString(data.getString("uuid")));
      this.setStatus(Status.valueOf(data.getString("status")));
      onStatus = data.getBoolean("onStatus");

    } catch (FileNotFoundException e) {
      System.out.println(e);
    }
  }
  
  public String toString () {
	  return "smartPlug" + this.getIdentifier(); 
  }

}
