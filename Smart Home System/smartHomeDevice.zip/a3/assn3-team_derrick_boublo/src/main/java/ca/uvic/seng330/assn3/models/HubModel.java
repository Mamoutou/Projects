package ca.uvic.seng330.assn3.models;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.Reader;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;


public class HubModel { 
  
  private HashMap<UUID, DeviceModel> deviceMap = new HashMap<>();
  private HashMap<UUID, User> userMap = new HashMap<>();
  private static final String deviceFilename = "devices.json";
  private static final String userFilename = "users.json";

  public HubModel() {
    File userFile = new File(userFilename);
    File devFile = new File(deviceFilename);
    // If these files do not exist, we have no offline storage to load.
    if (userFile.exists() || devFile.exists()) { 
      fileToData();
    }
  }

  public void registerDev(DeviceModel device) throws HubRegistrationException {

    if (deviceMap.containsKey(device.getIdentifier())) {
      throw new HubRegistrationException("Device already in registry");
    } 
    deviceMap.put(device.getIdentifier(), device);   
  }

  public void unregisterDev(DeviceModel device) throws HubRegistrationException {

    if (!deviceMap.containsKey(device.getIdentifier())) {
      throw new HubRegistrationException("Device not in registry");
    }
    deviceMap.remove(device.getIdentifier());
  }

  public Collection<DeviceModel> getDevices() {
    return deviceMap.values();
  }
  
  public void registerUser(User user) throws HubRegistrationException {
    
    if (userMap.containsKey(user.getIdentifier())) {
      throw new HubRegistrationException("User already in registry");
    } 
    userMap.put(user.getIdentifier(), user);
  }

  public void unregisterUser(User user) throws HubRegistrationException {

    if (!userMap.containsKey(user.getIdentifier())) {
      throw new HubRegistrationException("User not in registry");
    }
    userMap.remove(user.getIdentifier());
  }

  public Collection<User> getUsers() {
    return userMap.values();
  }
  
  public void dataToFile() {

    JSONArray dataArr = new JSONArray();

    for (DeviceModel device : deviceMap.values()) {
      JSONObject data = new JSONObject();

      data.put("uuid", device.getIdentifier().toString());
      // Get subclass type and store it in JSON file.
      if (device instanceof CameraModel) {
        data.put("type", "camera");
      } else if (device instanceof LightbulbModel) {
        data.put("type", "lightbulb");
      } else if (device instanceof SmartPlugModel) {
        data.put("type", "smartplug");
      } else if (device instanceof ThermostatModel) {
        data.put("type", "thermostat");
      }
      dataArr.put(data);
    }

    try {
      PrintWriter file = new PrintWriter(new FileOutputStream(deviceFilename, false));
      file.write(dataArr.toString());
      file.close();
    } catch (FileNotFoundException e) {
      System.out.println(e);
    }

    dataArr = new JSONArray();
    for (User user : userMap.values()) {
      JSONObject data = new JSONObject();
      data.put("uuid", user.getIdentifier().toString());
      data.put("name", user.getUserName());
      data.put("password", user.getPassword());
      data.put("type", user.getUserType().name());

      dataArr.put(data);
    }
    try {

      PrintWriter file = new PrintWriter(new FileOutputStream(userFilename, false));
      file.write(dataArr.toString());
      file.close();

    } catch (FileNotFoundException e) {
      System.out.println(e);
    }
  }

  public void fileToData() {

    try {
      Reader reader = new FileReader(userFilename);
      JSONTokener tokenizer = new JSONTokener(reader);
      JSONArray data = new JSONArray(tokenizer);

      for (int i = 0; i < data.length(); i++) {
        JSONObject userData = data.getJSONObject(i);
        User user = new User(UUID.fromString(userData.getString("uuid")),
            userData.getString("name"), userData.getString("password"),
            UserType.valueOf(userData.getString("type")));

        userMap.put(user.getIdentifier(), user);
      }

    } catch (FileNotFoundException e) {
      System.out.println(e);
    }

    try {
      Reader reader = new FileReader(deviceFilename);
      JSONTokener tokenizer = new JSONTokener(reader);
      JSONArray data = new JSONArray(tokenizer);

      for (int i = 0; i < data.length(); i++) {
        JSONObject deviceData = data.getJSONObject(i);

        String deviceType = deviceData.getString("type");

        if (deviceType.equals("camera")) {
          CameraModel cam = new CameraModel(UUID.fromString(deviceData.getString("uuid")));
          deviceMap.put(cam.getIdentifier(), cam);

        } else if (deviceType.equals("lightbulb")) {
          LightbulbModel light = new LightbulbModel(UUID.fromString(deviceData.getString("uuid")));
          deviceMap.put(light.getIdentifier(), light);

        } else if (deviceType.equals("smartplug")) {
          SmartPlugModel plug = new SmartPlugModel(UUID.fromString(deviceData.getString("uuid")));
          deviceMap.put(plug.getIdentifier(), plug);

        } else if (deviceType.equals("thermostat")) {
          ThermostatModel therm = new ThermostatModel(
              UUID.fromString(deviceData.getString("uuid")));
          deviceMap.put(therm.getIdentifier(), therm);
        }
      }

    } catch (FileNotFoundException e) {
      System.out.println(e);
    }
  }
}