package ca.uvic.seng330.assn3.models;

import java.util.UUID;

public abstract class DeviceModel {

  private UUID uuid;
  private Status status; // This can't be NULL!


  public DeviceModel() {
    uuid = UUID.randomUUID();
    status = Status.NORMAL;
  }

  public UUID getIdentifier() {
    return uuid;
  }

  void setIdentifier(UUID uuid) {
    this.uuid = uuid;
  }

  public Status getStatus() {
    // Since the status can't be NULL, then check IF NULL and IF return dummy
    // status.
    return status == null ? Status.NOT_AVAILABLE : status;
  }

  public void setStatus(Status status) {
    this.status = status;
  }

  @Override
  public String toString() {
    return  uuid.toString();
  }
  
  //Converts data to a JSON file.
  public abstract void dataToFile();
  
  abstract void fileToData(UUID uuid);

}