package ca.uvic.seng330.assn3.models;

import java.util.UUID;

public class User {
  private String userName;
  private String userPassword;
  private UUID id;
  private UserType userType;

  public User(String uName, String uPassword, UserType uType) {
    id = UUID.randomUUID();
    userName = uName;
    userPassword = uPassword;
    userType = uType;
  }

  public User(UUID uuid, String uName, String uPassword, UserType uType) {
    id = uuid;
    userName = uName;
    userPassword = uPassword;
    userType = uType;
  }

  public void setUserType(UserType ut) {
    this.userType = ut;
  }

  public void setUserPassword(String uPassword) {
    userPassword = uPassword;
  }

  public void setUserName(String uName) {
    userName = uName;
  }

  public String getUserName() {
    return userName;
  }

  public String getPassword() {
    return userPassword;
  }

  public UUID getIdentifier() {
    return id;
  }

  public String userNamePassword() {
    return this.getUserName() + " " + this.getPassword();
  }

  public UserType getUserType() {
    return this.userType;
  }


  public boolean equals(Object obj) {

    if (this == obj) {
      return true;
    } else if (obj == null || obj.getClass() != this.getClass()) {
      return false;
    } else {
      User u = (User) obj;
        return this.getPassword().equals(u.getPassword()) && this.getUserName().equals(u.getUserName())
                && this.getUserType().equals(u.getUserType());

    }
  }

  public String toString() {
    return this.getUserName() + " " + this.getPassword() + " " + this.getIdentifier();
  }

}
