package ca.uvic.seng330.assn3.views;

import java.util.ArrayList;
import java.util.Collection;

import ca.uvic.seng330.assn3.controllers.DeviceCtr;
import ca.uvic.seng330.assn3.controllers.HubCtr;
import ca.uvic.seng330.assn3.models.DeviceModel;
import ca.uvic.seng330.assn3.models.Status;

public class DeviceStatus extends Thread {
	HubCtr hubCtr;

	public DeviceStatus(HubCtr hub) {
		hubCtr = hub;

	}

	public void getStatus() {

		Collection<DeviceModel> devices = hubCtr.getDevices();

		for (DeviceModel device : devices) {
			hubCtr.log(device.toString() + " " + device.getStatus());
		}
	}

	public void run() {
		getStatus();
	}

}
