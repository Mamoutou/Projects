package ca.uvic.seng330.assn3.models;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.Reader;

import java.util.UUID;

import org.json.JSONObject;
import org.json.JSONTokener;

public class LightbulbModel extends DeviceModel {
  private boolean onStatus; // If lightbulb is on or off.

  public LightbulbModel() {
    super();
  }

  public LightbulbModel(UUID uuid) {
    fileToData(uuid);
  }
  
  public boolean getCondition() {
    return onStatus;
  }

  public void setCondition(boolean condition) {
    this.onStatus = condition;
  }
  
  public String toString () {
	  return "Lightbulb" + this.getIdentifier(); 
  }
 
  public void dataToFile() {
    String filename = "lightData" + this.getIdentifier().toString() + ".json";

    JSONObject data = new JSONObject();
    data.put("uuid", this.getIdentifier().toString());
    data.put("status", this.getStatus().name());
    data.put("onStatus", onStatus);

    try {
      PrintWriter file = new PrintWriter(new FileOutputStream(filename, false));
      file.write(data.toString());
      file.close();
    } catch (FileNotFoundException e) {
      System.out.println(e);
    }
  }

  void fileToData(UUID uuid) {
    String filename = "lightData" + uuid.toString() + ".json";

    try {
      Reader reader = new FileReader(filename);
      JSONTokener tokenizer = new JSONTokener(reader);
      JSONObject data = new JSONObject(tokenizer);

      this.setIdentifier(UUID.fromString(data.getString("uuid")));
      this.setStatus(Status.valueOf(data.getString("status")));
      onStatus = data.getBoolean("onStatus");

    } catch (FileNotFoundException e) {
      System.out.println(e);
    }
    
    
  }

}
