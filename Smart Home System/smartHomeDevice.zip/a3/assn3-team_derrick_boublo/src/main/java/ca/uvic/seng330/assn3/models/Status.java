package ca.uvic.seng330.assn3.models;

public enum Status {
  NORMAL, ERROR, OFF, NOT_AVAILABLE, ON

}