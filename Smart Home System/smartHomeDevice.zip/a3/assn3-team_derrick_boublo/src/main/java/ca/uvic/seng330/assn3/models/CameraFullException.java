package ca.uvic.seng330.assn3.models;


public class CameraFullException extends Exception {

  public CameraFullException(String errorMessage) {
    super(errorMessage);
  }

}