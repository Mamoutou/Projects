package ca.uvic.seng330.assn3.models;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.Reader;

import java.util.UUID;

import org.json.JSONObject;
import org.json.JSONTokener;


public class CameraModel extends DeviceModel {
  private boolean isRecording;
  private int diskSize;
  private static final int MAXDISKSIZE = 50;

  public CameraModel() {
    super();
    isRecording = false;
    diskSize = 0;
  }

  public CameraModel(UUID uuid) {
    fileToData(uuid);
  }

  public boolean isRecording() {
    return isRecording;
  }
  
  public void setisRecording(boolean camStatus) throws CameraFullException {
    if (diskSize > MAXDISKSIZE) {
      throw new CameraFullException("Camera is full.");
    }
    diskSize++;
    isRecording = camStatus;
  }

  public void dataToFile() {
    String filename = "cameraData" + this.getIdentifier().toString() + ".json";
    JSONObject data = new JSONObject();
    data.put("uuid", this.getIdentifier().toString());
    data.put("status", this.getStatus().name());
    data.put("diskSize", diskSize);
    data.put("isRecording", isRecording);

    try {
      PrintWriter file = new PrintWriter(new FileOutputStream(filename, false));
      file.write(data.toString());
      file.close();

    } catch (FileNotFoundException e) {
      System.out.println(e);
    }
  }
  
  public String toString () {
	  return "Camera" + this.getIdentifier(); 
  }

  void fileToData(UUID uuid) {
    String filename = "cameraData" + uuid.toString() + ".json";

    try {
      Reader reader = new FileReader(filename);
      JSONTokener tokenizer = new JSONTokener(reader);
      JSONObject data = new JSONObject(tokenizer);

      this.setIdentifier(UUID.fromString(data.getString("uuid")));
      this.setStatus(Status.valueOf(data.getString("status")));
      diskSize = data.getInt("diskSize");
      isRecording = data.getBoolean("isRecording");

    } catch (FileNotFoundException e) {
      System.out.println(e);
    }
  
    
  }

}


