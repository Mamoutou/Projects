package ca.uvic.seng330.assn3.views;
//TODO: Implement JavaFX UI code.

import ca.uvic.seng330.assn3.controllers.CameraCtr;
import ca.uvic.seng330.assn3.controllers.DeviceCtr;
import ca.uvic.seng330.assn3.controllers.HubCtr;
import ca.uvic.seng330.assn3.controllers.LightbulbCtr;
import ca.uvic.seng330.assn3.controllers.SmartPlugCtr;
import ca.uvic.seng330.assn3.controllers.ThermostatCtr;
import ca.uvic.seng330.assn3.models.User;
import ca.uvic.seng330.assn3.models.UserType;
import ca.uvic.seng330.assn3.models.CameraFullException;
import ca.uvic.seng330.assn3.models.CameraModel;
import ca.uvic.seng330.assn3.models.DeviceModel;
import ca.uvic.seng330.assn3.models.HubRegistrationException;
import ca.uvic.seng330.assn3.models.LightbulbModel;
import ca.uvic.seng330.assn3.models.SmartPlugModel;
import ca.uvic.seng330.assn3.models.Status;
import ca.uvic.seng330.assn3.models.Temperature;
import ca.uvic.seng330.assn3.models.ThermostatModel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import javafx.stage.Window;
import ca.uvic.seng330.assn3.models.Temperature.TemperatureOutofBoundsException;
import ca.uvic.seng330.assn3.models.Temperature.Unit;

public class View extends Application {
	static HubCtr hubCtr;
	private GridPane gridPane;
	private Scene scene;
	LightbulbCtr lightbulb;
	SmartPlugCtr smartPlug;
	CameraCtr camera;
	ThermostatCtr thermostat;

	public void initView(Stage primaryStage) {
		primaryStage.setTitle("Login");
		createRegistrationFormPane();
		hubCtr = new HubCtr();

		try {
			addUIControls(gridPane);
		} catch (IOException e) {
			System.out.println(e);
		}
		scene = new Scene(gridPane, 450, 350);
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		hubCtr = new HubCtr();
		primaryStage.setTitle("Login");
		createRegistrationFormPane();
		addUIControls(gridPane);
		scene = new Scene(gridPane, 450, 350);
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	public Scene getScene() {
		return scene;
	}

	// for user and admin
	private void createRegistrationFormPane() {
		gridPane = new GridPane();
		gridPane.setAlignment(Pos.CENTER);
		gridPane.setPadding(new Insets(40, 40, 40, 40));
		gridPane.setHgap(20);
		gridPane.setVgap(20);
		ColumnConstraints columnOneConstraints = new ColumnConstraints(100, 100, Double.MAX_VALUE);
		columnOneConstraints.setHalignment(HPos.RIGHT);
		ColumnConstraints columnTwoConstrains = new ColumnConstraints(100, 100, Double.MAX_VALUE);
		columnTwoConstrains.setHgrow(Priority.ALWAYS);
		gridPane.getColumnConstraints().addAll(columnOneConstraints, columnTwoConstrains);
		// return gridPane;
	}

	private void addUIControls(GridPane gridPane) throws IOException {
		Label headerLabel = new Label("User / Administractor");
		headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
		gridPane.add(headerLabel, 0, 0, 2, 1);
		GridPane.setHalignment(headerLabel, HPos.CENTER);
		GridPane.setMargin(headerLabel, new Insets(10, 0, 10, 0));

		Label nameLabel = new Label("Name: ");
		gridPane.add(nameLabel, 0, 1);
		TextField nameField = new TextField();
		nameField.setId("userField");

		nameField.setPromptText("Enter userName/AdminName");
		nameField.setPrefHeight(15);
		gridPane.add(nameField, 1, 1);

		Label passwordLabel = new Label("Password:");
		gridPane.add(passwordLabel, 0, 2);
		PasswordField passwordField = new PasswordField();
		passwordField.setId("passField");

		passwordField.setPromptText("Enter password");
		passwordField.setPrefHeight(15);
		gridPane.add(passwordField, 1, 2);

		Button singIn = new Button("Sign-In");
		singIn.setId("signIn");

		singIn.setPrefHeight(40);
		singIn.setDefaultButton(true);
		singIn.setPrefWidth(200);
		gridPane.add(singIn, 0, 4, 2, 1);
		GridPane.setHalignment(singIn, HPos.CENTER);
		GridPane.setMargin(singIn, new Insets(20, 0, 5, 0));

		Button signUpUser = new Button("Sign-Up User");
		signUpUser.setId("signUpUser");
		signUpUser.setPrefHeight(40);
		signUpUser.setDefaultButton(true);
		signUpUser.setPrefWidth(200);
		gridPane.add(signUpUser, 0, 5, 2, 1);
		GridPane.setHalignment(signUpUser, HPos.CENTER);
		GridPane.setMargin(signUpUser, new Insets(5, 0, 5, 0));

		Button signUpAdmin = new Button("Sign-Up Administractor");
		signUpAdmin.setId("signUpAdmin");

		signUpAdmin.setPrefHeight(40);
		signUpAdmin.setDefaultButton(true);
		signUpAdmin.setPrefWidth(200);
		gridPane.add(signUpAdmin, 0, 6, 2, 1);
		GridPane.setHalignment(signUpAdmin, HPos.CENTER);
		GridPane.setMargin(signUpAdmin, new Insets(5, 0, 5, 0));

		singIn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				if (nameField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter your name");
					return;
				}
				if (passwordField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter a password");
					return;
				}

				User user = new User(nameField.getText(), passwordField.getText(), UserType.BASIC);

				if (hubCtr.containUser(user)) {

					Stage secondStage = new Stage();
					GridPane gridPane = createRegistrationFormPaneUser();
					addUIControlsUser(gridPane);
					Scene scene = new Scene(gridPane, 450, 450);
					secondStage.setScene(scene);
					secondStage.show();

				} else {
					user.setUserType(UserType.ADMIN);
					if (hubCtr.containUser(user)) {

						Stage thirdStage = new Stage();
						GridPane gridPane = createDevicePane();
						addUIControlsDevies(gridPane);
						Scene scene = new Scene(gridPane, 900, 600);
						thirdStage.setScene(scene);
						thirdStage.show();
						
						TextArea textArea = new TextArea();
						textArea.setPrefHeight(300);
						textArea.setPrefWidth(300);
						gridPane.add(textArea, 5,0 , 2, 1);
						GridPane.setHalignment(textArea, HPos.LEFT);
						GridPane.setMargin(textArea, new Insets(5, 0, 5, 0));		
						showLog(textArea);

					} else {
						showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
								"Please sign up or verify username and password");
					}

				}
			}
		});

		signUpUser.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				if (nameField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter your name");
					return;
				}

				if (passwordField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter a password");
					return;
				}

				User user = new User(nameField.getText(), passwordField.getText(), UserType.BASIC);

				try {
					// HubCtr hubCtr = new HubCtr();
					hubCtr.registerUser(user);
					showAlert(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(), "Registration Successful!",
							"Welcome User " + nameField.getText());

				} catch (HubRegistrationException ex) {

				} catch (Exception ex) {

				}

				nameField.setText("");
				passwordField.setText("");
			}
		});

		signUpAdmin.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (nameField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter your name");
					return;
				}

				if (passwordField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter a password");
					return;
				}

				User admin = new User(nameField.getText(), passwordField.getText(), UserType.ADMIN);

				try {
					hubCtr.registerUser(admin);
					showAlert(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(), "Registration Successful!",
							"Welcome Administractor " + nameField.getText());
				} catch (HubRegistrationException ex) {

				} catch (Exception ex) {

				}
				nameField.setText("");
				passwordField.setText("");
			}
		});
	}

	// user
	private GridPane createRegistrationFormPaneUser() {
		GridPane gridPane = new GridPane();
		gridPane.setAlignment(Pos.CENTER);
		gridPane.setPadding(new Insets(40, 40, 40, 40));
		gridPane.setHgap(20);
		gridPane.setVgap(20);
		ColumnConstraints columnOneConstraints = new ColumnConstraints(100, 100, Double.MAX_VALUE);
		columnOneConstraints.setHalignment(HPos.RIGHT);
		ColumnConstraints columnTwoConstrains = new ColumnConstraints(100, 100, Double.MAX_VALUE);
		columnTwoConstrains.setHgrow(Priority.ALWAYS);
		gridPane.getColumnConstraints().addAll(columnOneConstraints, columnTwoConstrains);
		return gridPane;
	}

	private void addUIControlsUser(GridPane gridPane) {
		Label headerLabel = new Label("User");
		headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
		gridPane.add(headerLabel, 0, 0, 2, 1);
		GridPane.setHalignment(headerLabel, HPos.CENTER);
		GridPane.setMargin(headerLabel, new Insets(10, 0, 10, 0));

		Label nameLabel = new Label("Name: ");
		gridPane.add(nameLabel, 0, 1);
		TextField nameField = new TextField();
		nameField.setPromptText("Enter userName");
		nameField.setPrefHeight(15);
		gridPane.add(nameField, 1, 1);

		Label passwordLabel = new Label("Password:");
		gridPane.add(passwordLabel, 0, 2);
		PasswordField passwordField = new PasswordField();
		passwordField.setPromptText("Enter password");
		passwordField.setPrefHeight(15);
		gridPane.add(passwordField, 1, 2);

		Button registerUser = new Button("Register User");
		registerUser.setPrefHeight(40);
		registerUser.setDefaultButton(true);
		registerUser.setPrefWidth(200);
		gridPane.add(registerUser, 0, 4, 2, 1);
		GridPane.setHalignment(registerUser, HPos.CENTER);
		GridPane.setMargin(registerUser, new Insets(20, 0, 5, 0));

		Button unRegisterUser = new Button("Unregister User");
		unRegisterUser.setPrefHeight(40);
		unRegisterUser.setDefaultButton(true);
		unRegisterUser.setPrefWidth(200);
		gridPane.add(unRegisterUser, 0, 5, 2, 1);
		GridPane.setHalignment(unRegisterUser, HPos.CENTER);
		GridPane.setMargin(unRegisterUser, new Insets(5, 0, 5, 0));

		Button findUser = new Button("find User");
		findUser.setPrefHeight(40);
		findUser.setDefaultButton(true);
		findUser.setPrefWidth(200);
		gridPane.add(findUser, 0, 6, 2, 1);
		GridPane.setHalignment(findUser, HPos.CENTER);
		GridPane.setMargin(findUser, new Insets(5, 0, 5, 0));

		Button findAllUser = new Button("find All Users");
		findAllUser.setPrefHeight(40);
		findAllUser.setDefaultButton(true);
		findAllUser.setPrefWidth(200);
		gridPane.add(findAllUser, 0, 7, 2, 1);
		GridPane.setHalignment(findAllUser, HPos.CENTER);
		GridPane.setMargin(findAllUser, new Insets(5, 0, 5, 0));

		registerUser.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				if (nameField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter Username");
					return;
				}
				if (passwordField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter user password password");
					return;
				}

				User u1 = new User(nameField.getText(), passwordField.getText(), UserType.BASIC);
				try {
					hubCtr.registerUser(u1);
					// string name = "created"+ u1.getUserName();
					hubCtr.log(u1.toString());
					showAlert(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(), "Registered User!",
							"Welcome User " + nameField.getText());
				} catch (HubRegistrationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				nameField.setText("");
				passwordField.setText("");
			}
		});

		unRegisterUser.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				if (nameField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter Username");
					return;
				}
				if (passwordField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter user password");
					return;
				}

				User u = new User(nameField.getText(), passwordField.getText(), UserType.BASIC);

				try {
					hubCtr.unregisterUser(u);
					showAlert(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(), "Unregistered !",
							"User " + nameField.getText());
				} catch (Exception e) {
					showAlert(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(),
							"Sorry, user does not exist!", "Could not find user: " + nameField.getText());
				}

				nameField.setText("");
				passwordField.setText("");
			}
		});

		findUser.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				if (nameField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter Username");
					return;
				}
				if (passwordField.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!",
							"Please enter user password password");
					return;
				}

				User user = new User(nameField.getText(), passwordField.getText(), UserType.BASIC);
				try {
					if (hubCtr.containUser(user)) {
						showAlert(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(), "Found !",
								"Found User: " + nameField.getText());
					} else {
						showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "coudn't Find !",
								"Please Register User: " + nameField.getText());

					}
				} catch (Exception e) {
					showAlert(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(), "Sorry, didn't find !",
							"could not find User: " + nameField.getText());
				}
				nameField.setText("");
				passwordField.setText("");
			}
		});

		findAllUser.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				try {
					TextArea textArea = new TextArea();
					gridPane.add(textArea, 0, 8, 2, 1);
					GridPane.setHalignment(textArea, HPos.LEFT);
					GridPane.setMargin(textArea, new Insets(5, 0, 5, 0));
					hubCtr.displayBasicUsers(textArea);

				} catch (Exception e) {
					showAlert(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(), "Sorry, no user created!",
							"Please create users first! " + "");
				}
				nameField.setText("");
				passwordField.setText("");
			}
		});

	}

	private GridPane createDevicePane() {
		GridPane gridPane = new GridPane();
		gridPane.setAlignment(Pos.BASELINE_LEFT);
		gridPane.setPadding(new Insets(40, 40, 40, 40));
		gridPane.setHgap(20);
		gridPane.setVgap(20);
		ColumnConstraints columnOneConstraints = new ColumnConstraints(100, 100, Double.MAX_VALUE);
		columnOneConstraints.setHalignment(HPos.RIGHT);
		ColumnConstraints columnTwoConstrains = new ColumnConstraints(100, 100, Double.MAX_VALUE);
		columnTwoConstrains.setHgrow(Priority.ALWAYS);
		gridPane.getColumnConstraints().addAll(columnOneConstraints, columnTwoConstrains);
		return gridPane;
	}

	private void addUIControlsDevies(GridPane gridPane) {

		Label headerLabel = new Label("HOME DEVICES");
		headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 25));
		gridPane.add(headerLabel, 0, 0, 2, 1);
		GridPane.setHalignment(headerLabel, HPos.LEFT);
		GridPane.setMargin(headerLabel, new Insets(10, 0, 10, 0));

		Button getStatus = new Button("Log Home Devices Status");
		getStatus.setPrefHeight(10);
		getStatus.setDefaultButton(true);
		getStatus.setPrefWidth(180);
		gridPane.add(getStatus, 2, 0, 2, 1);
		GridPane.setHalignment(getStatus, HPos.RIGHT);
		GridPane.setMargin(getStatus, new Insets(5, 0, 5, 0));
		// buttonON(ON, cameraField); // turn device on

		Label cameraLabel = new Label("CAMERA: ");
		gridPane.add(cameraLabel, 0, 1);
		TextField cameraField = new TextField("OFF");
		cameraField.setPrefHeight(15);
		gridPane.add(cameraField, 1, 1);

		Label StatusLabel = new Label("Camera Status: ");
		StatusLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
		gridPane.add(StatusLabel, 2, 1);
		TextField statusField = new TextField("Offline");
		cameraField.setPrefHeight(10);
		gridPane.add(statusField, 3, 1);

		Button ON = new Button("ON");
		ON.setPrefHeight(10);
		ON.setDefaultButton(true);
		ON.setPrefWidth(50);
		gridPane.add(ON, 0, 2);
		GridPane.setHalignment(ON, HPos.LEFT);
		GridPane.setMargin(ON, new Insets(5, 0, 5, 0));
		buttonON(ON, cameraField); // turn device on

		Button OFF = new Button("OFF");
		OFF.setPrefHeight(10);
		OFF.setDefaultButton(true);
		OFF.setPrefWidth(50);
		gridPane.add(OFF, 1, 2);
		GridPane.setHalignment(OFF, HPos.LEFT);
		GridPane.setMargin(OFF, new Insets(5, 0, 5, 0));
		buttonOFF(OFF, cameraField); // turn device off

		Button recording = new Button("Record");
		recording.setPrefHeight(10);
		recording.setDefaultButton(true);
		recording.setPrefWidth(100);
		gridPane.add(recording, 2, 2);
		GridPane.setHalignment(recording, HPos.LEFT);
		GridPane.setMargin(recording, new Insets(5, 0, 5, 0));

		Button createCamera = new Button("createCamera");
		createCamera.setPrefHeight(10);
		createCamera.setDefaultButton(true);
		createCamera.setPrefWidth(100);
		gridPane.add(createCamera, 3, 2);
		GridPane.setHalignment(createCamera, HPos.LEFT);
		GridPane.setMargin(createCamera, new Insets(5, 0, 5, 0));

		Button liveScream = new Button("live Scream");
		liveScream.setPrefHeight(10);
		liveScream.setDefaultButton(true);
		liveScream.setPrefWidth(100);
		gridPane.add(liveScream, 4, 2);
		GridPane.setHalignment(liveScream, HPos.LEFT);
		GridPane.setMargin(liveScream, new Insets(5, 0, 5, 0));
//////////////////////////////////////////////////////////////////////////////////////////////////
		Label thermostatLabel = new Label("THERMOSTAT: ");
		gridPane.add(thermostatLabel, 0, 4);
		TextField thermostatField = new TextField("OFF");
		thermostatField.setPrefHeight(15);
		gridPane.add(thermostatField, 1, 4);

		Button OnThermostat = new Button("ON");
		OnThermostat.setPrefHeight(10);
		OnThermostat.setDefaultButton(true);
		OnThermostat.setPrefWidth(50);
		gridPane.add(OnThermostat, 0, 5);
		GridPane.setHalignment(OnThermostat, HPos.LEFT);
		GridPane.setMargin(OnThermostat, new Insets(5, 0, 5, 0));
		buttonON(OnThermostat, thermostatField); // turn device on

		Button OffThermostat = new Button("OFF");
		OffThermostat.setPrefHeight(10);
		OffThermostat.setDefaultButton(true);
		OffThermostat.setPrefWidth(50);
		gridPane.add(OffThermostat, 1, 5);
		GridPane.setHalignment(OffThermostat, HPos.LEFT);
		GridPane.setMargin(OffThermostat, new Insets(5, 0, 5, 0));
		buttonOFF(OffThermostat, thermostatField); // turn device on

		Button createThermostat = new Button("Create Thermostat");
		createThermostat.setPrefHeight(7);
		createThermostat.setDefaultButton(true);
		createThermostat.setPrefWidth(150);
		gridPane.add(createThermostat, 4, 5);
		GridPane.setHalignment(createThermostat, HPos.LEFT);
		GridPane.setMargin(createThermostat, new Insets(5, 0, 5, 0));

		Button changeTemperature = new Button("Change Temperature");
		changeTemperature.setPrefHeight(10);
		changeTemperature.setDefaultButton(true);
		changeTemperature.setPrefWidth(150);
		gridPane.add(changeTemperature, 2, 5);
		GridPane.setHalignment(changeTemperature, HPos.LEFT);
		GridPane.setMargin(changeTemperature, new Insets(5, 0, 5, 0));

		Button changeUnit = new Button("Change Unit");
		changeUnit.setPrefHeight(10);
		changeUnit.setDefaultButton(true);
		changeUnit.setPrefWidth(100);
		gridPane.add(changeUnit, 3, 5);
		GridPane.setHalignment(changeUnit, HPos.LEFT);
		GridPane.setMargin(changeUnit, new Insets(5, 0, 5, 0));

		TextField degreeNumber = new TextField("");
		degreeNumber.setPromptText("Enter a number");
		degreeNumber.setPrefHeight(5);
		degreeNumber.setPrefWidth(18);
		gridPane.add(degreeNumber, 2, 4);

		TextField degree = new TextField("");
		degree.setDisable(true);
		degree.setPrefHeight(5);
		degree.setPrefWidth(18);
		gridPane.add(degree, 3, 4);

		Label StatusTherLabel = new Label("Thermostat Status: ");
		StatusTherLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
		gridPane.add(StatusTherLabel, 4, 4);
		TextField statusTherField = new TextField("Offline");
		statusTherField.setPrefHeight(5);
		gridPane.add(statusTherField, 5, 4);

		Label LightbulbLabel = new Label("LIGHTBULB: ");
		gridPane.add(LightbulbLabel, 0, 6);
		TextField LightbulbField = new TextField("OFF");
		LightbulbField.setPrefHeight(15);
		gridPane.add(LightbulbField, 1, 6);

		Label StatusLightLabel = new Label("Lightbulb status: ");
		StatusLightLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
		gridPane.add(StatusLightLabel, 2, 6);
		TextField statusLightField = new TextField("Offline");
		statusLightField.setPrefHeight(5);
		gridPane.add(statusLightField, 3, 6);

		Button OnLightbul = new Button("ON");
		OnLightbul.setPrefHeight(10);
		OnLightbul.setDefaultButton(true);
		OnLightbul.setPrefWidth(50);
		gridPane.add(OnLightbul, 0, 7);
		GridPane.setHalignment(OnLightbul, HPos.LEFT);
		GridPane.setMargin(OnLightbul, new Insets(5, 0, 5, 0));
		buttonON(OnLightbul, LightbulbField); // turn device on

		Button OffLightbul = new Button("OFF");
		OffLightbul.setPrefHeight(10);
		OffLightbul.setDefaultButton(true);
		OffLightbul.setPrefWidth(50);
		gridPane.add(OffLightbul, 1, 7);
		GridPane.setHalignment(OffLightbul, HPos.LEFT);
		GridPane.setMargin(OffLightbul, new Insets(5, 0, 5, 0));
		buttonOFF(OffLightbul, LightbulbField); // turn device off

		Button createLightbul = new Button("Create Lightbulb");
		createLightbul.setPrefHeight(10);
		createLightbul.setDefaultButton(true);
		createLightbul.setPrefWidth(120);
		gridPane.add(createLightbul, 3, 7);
		GridPane.setHalignment(createLightbul, HPos.LEFT);
		GridPane.setMargin(createLightbul, new Insets(5, 0, 5, 0));

		Button ToogleLightbul = new Button("toggle");
		ToogleLightbul.setId("toggleLight");
		ToogleLightbul.setPrefHeight(10);
		ToogleLightbul.setDefaultButton(true);
		ToogleLightbul.setPrefWidth(100);
		gridPane.add(ToogleLightbul, 2, 7);
		GridPane.setHalignment(ToogleLightbul, HPos.LEFT);
		GridPane.setMargin(ToogleLightbul, new Insets(5, 0, 5, 0));

		Label SmartPlugLabel = new Label("SMARTPLUG: ");
		gridPane.add(SmartPlugLabel, 0, 8);
		TextField SmartPlugbField = new TextField("OFF");
		SmartPlugbField.setPrefHeight(15);
		gridPane.add(SmartPlugbField, 1, 8);

		Label StatudSmartPlugLabel = new Label("SmartPlug status: ");
		StatudSmartPlugLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
		gridPane.add(StatudSmartPlugLabel, 2, 8);
		TextField StatudSmartPlugLabelField = new TextField("Offline");
		StatudSmartPlugLabelField.setPrefHeight(5);
		gridPane.add(StatudSmartPlugLabelField, 3, 8);

		Button OnSmartPlug = new Button("ON");
		OnSmartPlug.setPrefHeight(10);
		OnSmartPlug.setDefaultButton(true);
		OnSmartPlug.setPrefWidth(50);
		gridPane.add(OnSmartPlug, 0, 9);
		GridPane.setHalignment(OnSmartPlug, HPos.LEFT);
		GridPane.setMargin(OnSmartPlug, new Insets(5, 0, 5, 0));
		buttonON(OnSmartPlug, SmartPlugbField); // turn device ON

		Button OffSmartPlug = new Button("OFF");
		OffSmartPlug.setPrefHeight(10);
		OffSmartPlug.setDefaultButton(true);
		OffSmartPlug.setPrefWidth(50);
		gridPane.add(OffSmartPlug, 1, 9);
		GridPane.setHalignment(OffSmartPlug, HPos.LEFT);
		GridPane.setMargin(OffSmartPlug, new Insets(5, 0, 5, 0));
		buttonOFF(OffSmartPlug, SmartPlugbField); // turn device OFF

		Button createSmartPlug = new Button("Create SmartPlug");
		createSmartPlug.setPrefHeight(10);
		createSmartPlug.setDefaultButton(true);
		createSmartPlug.setPrefWidth(120);
		gridPane.add(createSmartPlug, 3, 9);
		GridPane.setHalignment(createSmartPlug, HPos.LEFT);
		GridPane.setMargin(createSmartPlug, new Insets(5, 0, 5, 0));

		Button ToggleSmartPlug = new Button("Toggle");
		ToggleSmartPlug.setPrefHeight(10);
		ToggleSmartPlug.setDefaultButton(true);
		ToggleSmartPlug.setPrefWidth(100);
		gridPane.add(ToggleSmartPlug, 2, 9);
		GridPane.setHalignment(ToggleSmartPlug, HPos.LEFT);
		GridPane.setMargin(ToggleSmartPlug, new Insets(5, 0, 5, 0));

		createCamera.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				camera = new CameraCtr(hubCtr);
				try {

					hubCtr.registerDev(camera.getModel());
					// cameraField.setText(camera.getModel().getStatus().toString());
					statusField.setText("functioning");
					hubCtr.log("Camera creaded");
					showAlert(Alert.AlertType.INFORMATION, gridPane.getScene().getWindow(), "success!",
							"Camera created");
				} catch (HubRegistrationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});

		liveScream.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				Scene screen = new Scene(new Screen(), 500, 500, Color.web("#666970"));
				Stage screenStage = new Stage();
				screenStage.setScene(screen);
				screenStage.show();
			}
		});

		createThermostat.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				thermostat = new ThermostatCtr(hubCtr);
				try {
					hubCtr.registerDev(thermostat.getModel());
					// thermostatField.setText(thermostat.getModel().getStatus().toString());
					statusTherField.setText("functioning");
					String temperature = thermostat.getTemp() + " " + thermostat.getUnit().name();
					degree.setText(temperature);
					hubCtr.log("thermostat creaded");
					showAlert(Alert.AlertType.INFORMATION, gridPane.getScene().getWindow(), "success!",
							"thermostat created");
				} catch (HubRegistrationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});

		createSmartPlug.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				smartPlug = new SmartPlugCtr(hubCtr);
				try {
					hubCtr.registerDev(smartPlug.getModel());
					// SmartPlugbField.setText(smartPlug.getModel().getStatus().toString());
					StatudSmartPlugLabelField.setText("functioning");
					hubCtr.log("smartPlug creaded");
					showAlert(Alert.AlertType.INFORMATION, gridPane.getScene().getWindow(), "success!",
							"smartPlug created");
				} catch (HubRegistrationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});

		createLightbul.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				lightbulb = new LightbulbCtr(hubCtr);
				try {
					hubCtr.registerDev(lightbulb.getModel());
					// LightbulbField.setText(lightbulb.getModel().getStatus().toString());
					statusLightField.setText("functioning");
					hubCtr.log("lightbulb creaded");
					showAlert(Alert.AlertType.INFORMATION, gridPane.getScene().getWindow(), "success!",
							"lightbulb created");
				} catch (HubRegistrationException e) {
					e.printStackTrace();
				}

			}
		});

		ToggleSmartPlug.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (smartPlug == null) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Error!",
							"Please create SmartPlug");
					return;
				}
				smartPlug.toggle();
				if (smartPlug.getModel().getonStatus() == false) {
					ToggleSmartPlug.setStyle("-fx-background-color: #ff0000;");
				} else {
					ToggleSmartPlug.setStyle("-fx-background-color: #ffff00; ");
				}

			}
		});

		ToogleLightbul.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (lightbulb == null) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Error!",
							"Please create lightbulb");
					return;
				}
				lightbulb.toggle();
				if (lightbulb.getModel().getCondition() == false) {
					ToogleLightbul.setStyle("-fx-background-color: #ff0000; ");
				} else {
					ToogleLightbul.setStyle("-fx-background-color: #ffff00; ");
				}

			}
		});

		changeTemperature.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				double number;
				if (thermostat == null) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Error!",
							"Please create thermostat");
					return;
				}
				if (degreeNumber.getText().isEmpty()) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Error!", "Please a number");
					return;
				}

				try {
					number = Double.parseDouble(degreeNumber.getText());
					thermostat.changeTemp(number);
					String temperature = thermostat.getTemp() + " " + thermostat.getUnit().name();
					degree.setText(temperature);
					degreeNumber.setText("");
					;

				} catch (TemperatureOutofBoundsException e) {

					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Error",
							"Please pick a number under 150");
				}

			}
		});

		changeUnit.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				if (thermostat == null) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Error!",
							"Please create thermostat");
					return;
				}

				try {
					thermostat.convertUnits(thermostat.getTemperature());

					String numbertoString = String.format("%.2f", thermostat.getTemp());
					String temperature = numbertoString + " " + thermostat.getUnit().name();
					degree.setText(temperature);

				} catch (TemperatureOutofBoundsException e) {

					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Error",
							"Please pick a number under 150");
				}

			}
		});

		recording.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				if (camera == null) {
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Error!", "Please create camera");
					return;
				}
				try {
					camera.record();
				} catch (CameraFullException e) {
					// TODO Auto-generated catch block
					showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Error!", "camera Full");
					e.printStackTrace();
					return;
				}

				if (camera.getModel().isRecording() == false) {
					recording.setStyle("-fx-background-color: #ff0000; ");
				} else {
					recording.setStyle("-fx-background-color: #ffff00; ");
				}

			}
		});

		getStatus.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				DeviceStatus logThread = new DeviceStatus(hubCtr);
				logThread.start();
				showAlert(Alert.AlertType.INFORMATION, gridPane.getScene().getWindow(), "Sucess!",
						"Log has been updated");
			}
		});
	}

	private void buttonON(Button ON, TextField textfield) {
		ON.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				textfield.setText("ON");
			}
		});

	}

	private void buttonOFF(Button OFF, TextField textfield) {
		OFF.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				textfield.setText("OFF");
			}
		});
	}

	private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.initOwner(owner);
		alert.show();
	}

	public static void main(String[] args) {
		launch(args);
		hubCtr.shutdownSys();
	}

	public Parent asParent() {
		return gridPane;
	}

	public void showLog(TextArea textArea) {

		try {
			FileInputStream fstream = new FileInputStream("hub.log");
			BufferedReader br = new BufferedReader(new InputStreamReader(fstream));

			String strLine;
			while ((strLine = br.readLine()) != null) {
				textArea.appendText(strLine+"\n");
			}
			br.close();

		} catch (Exception e) {

		}
	}
	private class Screen extends Region {

		final WebView browser = new WebView();
		final WebEngine webEngine = browser.getEngine();

		public Screen() {
			getStyleClass().add("browser");
			webEngine.load("https://www.youtube.com");
			getChildren().add(browser);
		}

		private Node createSpacer() {
			Region spacer = new Region();
			HBox.setHgrow(spacer, Priority.ALWAYS);
			return spacer;
		}

		@Override
		protected void layoutChildren() {
			double w = getWidth();
			double h = getHeight();
			layoutInArea(browser, 0, 0, w, h, 0, HPos.CENTER, VPos.CENTER);
		}

		@Override
		protected double computePrefWidth(double height) {
			return 750;
		}

		@Override
		protected double computePrefHeight(double width) {
			return 500;
		}

	}
}