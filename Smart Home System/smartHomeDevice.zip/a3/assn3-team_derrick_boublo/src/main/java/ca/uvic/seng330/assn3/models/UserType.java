package ca.uvic.seng330.assn3.models;

public enum UserType {
   BASIC, ADMIN
}
