package ca.uvic.seng330.assn3.models;

public class HubRegistrationException extends Exception {
  public HubRegistrationException(String s) {
    super(s);
  }
}