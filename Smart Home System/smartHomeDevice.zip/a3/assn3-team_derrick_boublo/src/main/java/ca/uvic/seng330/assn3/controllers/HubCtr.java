package ca.uvic.seng330.assn3.controllers;

import ca.uvic.seng330.assn3.models.DeviceModel;
import ca.uvic.seng330.assn3.models.HubModel;
import ca.uvic.seng330.assn3.models.HubRegistrationException;
import ca.uvic.seng330.assn3.models.LightbulbModel;
import ca.uvic.seng330.assn3.models.Status;
import ca.uvic.seng330.assn3.models.User;

import java.io.IOException;

import java.util.Collection;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import javafx.scene.control.TextArea;

public class HubCtr {

	HubModel hubModel = new HubModel();
	private Logger logger;
	private FileHandler logFile;

	public HubCtr() {

		try {
			initLog();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	public void shutdownSys() {
		hubModel.dataToFile();

		Collection<DeviceModel> devList = hubModel.getDevices();
		for (DeviceModel dev : devList) {
			dev.dataToFile();
		}

	}

	// Retrieve an alert from a DeviceCtr, and possibly send it to another
	// device/user.

	public void alert(String message) {
		this.log(message);
		Collection<DeviceModel> devList = hubModel.getDevices();
		// Turn the light bulb on.
		if (message.equals("Camera detected movement in the room")) {
			for (DeviceModel dev : devList) {
				if (dev instanceof LightbulbModel) {
					LightbulbModel light = (LightbulbModel) dev;
					if (light.getCondition()) {
						return; // light already on.
					} else {
						light.setCondition(true);
					}
				}
			}
		} else if (message.equals("Camera detected someone leaving the room")) {
			for (DeviceModel dev : devList) {
				if (dev instanceof LightbulbModel) {
					LightbulbModel light = (LightbulbModel) dev;
					if (!light.getCondition()) {
						return; // light already off.
					} else {
						light.setCondition(false);
					}
				}
			}
		}
	}

	public Collection<DeviceModel> getDevices() {
		return hubModel.getDevices();
	}

	public Collection<User> getUsers() {
		return hubModel.getUsers();
	}

	public void log(String message) {
		logger.severe(message);
	}

	public void registerDev(DeviceModel device) throws HubRegistrationException {
		assert device != null;
		hubModel.registerDev(device);
	}

	public void registerUser(User user) throws HubRegistrationException {
		assert user != null;
		hubModel.registerUser(user);
	}

	public void startup() {

		for (DeviceModel device : hubModel.getDevices()) {
			device.setStatus(Status.NORMAL);
		}
	}

	public void shutdown() {

		for (DeviceModel device : hubModel.getDevices()) {
			device.setStatus(Status.OFF);
		}
	}

	public void unregisterDev(DeviceModel device) throws HubRegistrationException {
		assert device != null;
		hubModel.unregisterDev(device);
	}

	public void unregisterUser(User user) throws HubRegistrationException {
		assert user != null;
		hubModel.unregisterUser(user);
	}

	public boolean containUser(User u) {

		Collection<User> users = this.getUsers();

		for (User user : users) {
			if (user.equals(u)) {
				return true;
			}
		}
		return false;
	}

	private void initLog() throws IOException {
		// Init logger
		logFile = new FileHandler("hub.log", true);
		logger = Logger.getLogger("hub_log");
		logger.addHandler(logFile);
		logFile.setFormatter(new SimpleFormatter());
		
		logger.setLevel(Level.SEVERE);
	}

	public void displayBasicUsers(TextArea textArea) throws Exception {
		if (this.getUsers().isEmpty()) {
			throw new Exception("Empty set, no user has been created");
		} else {
			Collection<User> users = this.getUsers();
			for (User user : users)
				textArea.appendText(user.toString() + "\n");

		}
	}

	public void displayLogger(String message) throws Exception {

		// textArea.appendText(logger.log(Level.INFO, message);
	}
}