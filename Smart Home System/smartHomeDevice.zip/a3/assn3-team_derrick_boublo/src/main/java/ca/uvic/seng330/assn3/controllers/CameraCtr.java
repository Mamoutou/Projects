package ca.uvic.seng330.assn3.controllers;

import ca.uvic.seng330.assn3.models.CameraFullException;

import ca.uvic.seng330.assn3.models.CameraModel;
import ca.uvic.seng330.assn3.models.DeviceModel;
import ca.uvic.seng330.assn3.models.Status;

public class CameraCtr extends DeviceCtr {

  private CameraModel cameraModel;

  public CameraCtr(HubCtr hub) {
    super(hub);
    cameraModel = new CameraModel();
  }

  public void record() throws CameraFullException {

    if (cameraModel.isRecording()) {
      cameraModel.setisRecording(false);
    } else {
      cameraModel.setisRecording(true);
    }
  }

  public void enterRoom() {
    // Notify hubctr about a camera event (movement in room).
    hub.alert("Camera detected movement in the room");
  }

  public void leaveRoom() {
    // Notify hubctr about a camera event (someone leaving the room).
    hub.alert("Camera detected someone leaving the room");
  }

  public CameraModel getModel() {
    return cameraModel;
  }

}