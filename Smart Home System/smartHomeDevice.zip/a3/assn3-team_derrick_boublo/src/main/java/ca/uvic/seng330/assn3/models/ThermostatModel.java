package ca.uvic.seng330.assn3.models;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.Reader;

import java.util.UUID;

import org.json.JSONObject;
import org.json.JSONTokener;

public class ThermostatModel extends DeviceModel {
  private Temperature curTemp;

  public ThermostatModel(Temperature temp) {
    super();
    curTemp = temp;
  }

  public ThermostatModel() {
    super();
    curTemp = new Temperature();
  }

  public ThermostatModel(UUID uuid) {
    fileToData(uuid);
  }

  public void setTemp(Temperature temp) {
    assert temp != null;
    curTemp = new Temperature(temp);
  }

  public Temperature getTemp() {
    return new Temperature(curTemp);
  }

  public double getTempNum() {
    return curTemp.getTempNum();
  }

  public Temperature.Unit getUnit() {
    return curTemp.getUnit();
  }
  
  public String toString () {
	  return "Thermostat" + this.getIdentifier(); 
  }

  
  public void dataToFile() {
    String filename = "thermostatData" + this.getIdentifier().toString()
        + ".json";
    JSONObject data = new JSONObject();
    data.put("uuid", this.getIdentifier().toString());
    data.put("status", this.getStatus().name());
    data.put("tempNum", curTemp.getTempNum());
    data.put("tempUnit", curTemp.getUnit().name());

    try {
      PrintWriter file = new PrintWriter(new FileOutputStream(filename, false));
      file.write(data.toString());
      file.close();
    } catch (FileNotFoundException e) {
      System.out.println(e);
    }
  }
  

  void fileToData(UUID uuid) {
    String filename = "thermostatData" + uuid.toString() + ".json";
    try {
      Reader reader = new FileReader(filename);
      JSONTokener tokenizer = new JSONTokener(reader);
      JSONObject data = new JSONObject(tokenizer);

      this.setIdentifier(UUID.fromString(data.getString("uuid")));
      this.setStatus(Status.valueOf(data.getString("status")));

      curTemp = new Temperature(data.getDouble("tempNum"),
            Temperature.Unit.valueOf(data.getString("tempUnit")));

    } catch (FileNotFoundException e) {
      System.out.println(e);
    } catch (Temperature.TemperatureOutofBoundsException e) {
      System.out.println(e);
    }
    
  }
  
}
