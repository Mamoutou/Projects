package ca.uvic.seng330.assn3.controllers;

import ca.uvic.seng330.assn3.models.DeviceModel;

import ca.uvic.seng330.assn3.models.LightbulbModel;

import ca.uvic.seng330.assn3.models.Status;

public class LightbulbCtr extends DeviceCtr {
  private LightbulbModel lightbulbModel;
  
  public LightbulbCtr(HubCtr hub) {
    super(hub);
    lightbulbModel = new LightbulbModel();
    
  }

  // toggle the light from on to off/off to on
  public void toggle() {
    if (lightbulbModel.getCondition()) {
      lightbulbModel.setCondition(false);
    } else {
      lightbulbModel.setCondition(true);
    }
  }

  public LightbulbModel getModel() {
    return lightbulbModel;
  }

}