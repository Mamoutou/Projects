package ca.uvic.seng330.assn3.controllers;

import java.text.DecimalFormat;

import ca.uvic.seng330.assn3.models.DeviceModel;
import ca.uvic.seng330.assn3.models.Status;
import ca.uvic.seng330.assn3.models.Temperature;
import ca.uvic.seng330.assn3.models.Temperature.TemperatureOutofBoundsException;
import ca.uvic.seng330.assn3.models.ThermostatModel;

public class ThermostatCtr extends DeviceCtr {
	private ThermostatModel thermostatModel;

	public ThermostatCtr(HubCtr hub) {
		super(hub);
		thermostatModel = new ThermostatModel();
	}

	public void changeUnits(Temperature.Unit unit) throws TemperatureOutofBoundsException {

		Temperature curTemp = thermostatModel.getTemp();
		 if (curTemp.getUnit() == unit) {
			return; // unit is already correct
		} else {
			convertUnits(curTemp);
		}

	}

	public void changeTemp(double temp) throws TemperatureOutofBoundsException {

		thermostatModel.setTemp(new Temperature(temp, thermostatModel.getUnit()));

	}

	public double getTemp() {
		return thermostatModel.getTempNum();
	}

	public Temperature.Unit getUnit() {

		return thermostatModel.getUnit();
	}

	public void convertUnits(Temperature temp) throws TemperatureOutofBoundsException {

		Temperature.Unit newUnit;
		double newTemp;
		
		if (temp.getUnit() == Temperature.Unit.FAHRENHEIT) {
			newUnit = Temperature.Unit.CELSIUS;
			newTemp = (temp.getTempNum() - 32) / 1.8;

		} else {
			newUnit = Temperature.Unit.FAHRENHEIT;
			newTemp = (temp.getTempNum() * 1.8) + 32;
		}
		thermostatModel.setTemp(new Temperature(newTemp, newUnit));
	}
	
	public Temperature getTemperature() {
		return thermostatModel.getTemp();
	}
	
	public ThermostatModel getModel() {
		return thermostatModel;
	}
}