package ca.uvic.seng330.assn3.controllers;
import ca.uvic.seng330.assn3.models.DeviceModel;

public abstract class DeviceCtr {

  HubCtr hub;

  public DeviceCtr(HubCtr hub) {
    this.hub = hub;
  }

}