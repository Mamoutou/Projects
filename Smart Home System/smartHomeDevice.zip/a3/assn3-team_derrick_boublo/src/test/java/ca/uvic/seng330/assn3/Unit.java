package ca.uvic.seng330.assn3;
import ca.uvic.seng330.assn3.models.*;
import ca.uvic.seng330.assn3.controllers.*;

import org.hamcrest.core.IsInstanceOf;
import org.junit.*;
import org.junit.rules.Timeout;
import java.lang.reflect.Field;
import org.junit.rules.ExpectedException;
import static junit.framework.TestCase.*;

public class Unit {
  @Rule public ExpectedException thrown = ExpectedException.none();
  // B2
  @Test public void testRegister() {
    HubCtr h = new HubCtr();
    CameraCtr cam = new CameraCtr(h);
    try {
      h.registerDev(cam.getModel());
    } catch (HubRegistrationException e) {

    }
  }
  //B3
  @Test public void testUnRegister() {
    HubCtr h = new HubCtr();
    CameraCtr cam = new CameraCtr(h);
    try {
      h.registerDev(cam.getModel());
    } catch (HubRegistrationException e) {

    }
    try {
      h.unregisterDev(cam.getModel());
    } catch (HubRegistrationException e) {

    }
  }

  @Test public void testShutdown() {
    HubCtr h = new HubCtr();
    CameraCtr cam = new CameraCtr(h);
    ThermostatCtr therm = new ThermostatCtr(h);

    try {
      h.registerDev(cam.getModel());
      h.registerDev(therm.getModel());
    } catch (HubRegistrationException e) {

    }

    h.shutdownSys();
  }
  // E1
  @Test public void turnOnLight() {
    HubCtr h = new HubCtr();
    LightbulbCtr light = new LightbulbCtr(h);
    light.toggle();

    Assert.assertTrue("Light is on", light.getModel().getCondition());

  }
  // E2
  @Test public void turnOffLight() {
    HubCtr h = new HubCtr();
    LightbulbCtr light = new LightbulbCtr(h);
    light.toggle();
    light.toggle();

    Assert.assertFalse("Light is off", light.getModel().getCondition());
  }

  // C2
  @Test public void turnOnCamera() {
    HubCtr h = new HubCtr();
    CameraCtr cam = new CameraCtr(h);
    try {
      cam.record();
    } catch (CameraFullException e) {

    }
    Assert.assertTrue("Camera is recording", cam.getModel().isRecording());
  }

   // C3
  @Test public void turnOffCamera() {
    HubCtr h = new HubCtr();
    CameraCtr cam = new CameraCtr(h);
    try {
      cam.record();
      cam.record();
    } catch (CameraFullException e) {

    }
    Assert.assertFalse("Camera is not recording", cam.getModel().isRecording());
  }

  //C4
  @Test public void testCameraThrowsCameraFullException() throws CameraFullException {
    //Note: I took this from the A2 tests.
    HubCtr h = new HubCtr();
    CameraCtr c = new CameraCtr(h);
    CameraModel cModel = c.getModel();
    Field cDiskField = null;
    try {
      cDiskField = CameraModel.class.getDeclaredField("diskSize");
    } catch (NoSuchFieldException e) {
      fail("Camera class has no such private field 'diskSize'");
    }
    cDiskField.setAccessible(true);
    try {
      cDiskField.setInt(cModel,100);
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    }
    thrown.expect(CameraFullException.class);
    c.record();
  }


}