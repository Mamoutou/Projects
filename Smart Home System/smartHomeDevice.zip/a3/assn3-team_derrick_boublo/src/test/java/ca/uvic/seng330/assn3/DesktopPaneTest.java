package ca.uvic.seng330.assn3;

import ca.uvic.seng330.assn3.views.View;
import org.junit.*;

import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Parent;
import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;

import org.testfx.matcher.control.LabeledMatchers;
import org.testfx.matcher.control.TextInputControlMatchers;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.scene.layout.*;

//import javafx.embed.swing.JFXPanel;
//import org.loadui.testfx.GuiTest;
import static org.testfx.api.FxAssert.verifyThat;
import static org.junit.Assert.assertEquals;
public class DesktopPaneTest extends ApplicationTest {

  private Scene scene;
  private View view;

  @Override
  public void start(Stage primaryStage) {
    view = new View();
    view.initView(primaryStage);

    primaryStage.setScene(view.getScene());
    primaryStage.show();
    primaryStage.toFront();  
  }
  
   // Test A 1
  @Test public void shouldHaveSignin() {
    verifyThat(".button", LabeledMatchers.hasText("Sign-In"));
  }
  
  // Test A 2
  @Test public void shouldHaveUsersAdmin() {

    verifyThat("#signUpUser", LabeledMatchers.hasText("Sign-Up User"));
    verifyThat("#signUpAdmin", LabeledMatchers.hasText("Sign-Up Administractor"));
  } 
  
  // Test A3
  @Test public void shouldSeeUserScreen() {
    clickOn("#userField").write("user");
    clickOn("#passField").write("1234");
    clickOn("#signUpUser");
    clickOn("#userField").write("user");
    clickOn("#passField").write("1234");
    clickOn("#signIn");
  }
  
  // Test A4 - A7 and B4 and B6
  @Test public void shouldSeeAdmincreen() {
    clickOn("#userField").write("admin");
    clickOn("#passField").write("12345");
    clickOn("#signUpAdmin");
    clickOn("#userField").write("admin");
    clickOn("#passField").write("12345");
    clickOn("#signIn");
  }

}