#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define BUFFER_LEN 1024

//creating a node
typedef struct bg_pro{
    pid_t pid;
    char command [BUFFER_LEN];
    struct bg_pro* next;
} node;

node *head = NULL;
node *current = NULL;

//inserting node at the first location
void insertFirst(pid_t key, char comd[]) {
    node *link = (node*) malloc(sizeof(node));
   	link->pid = key;
   	int i = 0;
  	while (comd[i] != '\0'){
  	    link->command[i] = comd[i];
  	    ++i;
  	}
    link->next = head;
    head = link;
}
//deleting a specific node
node* delete(pid_t key) {
   node* current = head;
   node* previous = NULL;
   if(head == NULL) {
      return NULL;
   }
   while(current->pid != key) {
      if(current->next == NULL) {
           return NULL;
      } else {
           previous = current;
           current = current->next;
      }
   }
   if(current == head) {
        head = head->next;
   } else {
        previous->next = current->next;
   }
   return current;
}

void bg(char** userInput) {
   	char command[BUFFER_LEN];
  	pid_t pid = fork();
  	if (pid == 0) {
	    	execvp(command, &userInput[1]);
	    	exit(1);
	  } else if (pid > 0) {
	       insertFirst(pid,command);
		     sleep(1);
	  } else {
	     	printf("Error,failed to fork");
	  }
}

/*displays all programs running processes in the background */
void bglist() {
    	int count = 0;
    	node *iterator = head;
    	while (iterator != NULL) {
	               count++;
		       printf("background process: # %d id is %d:\t%s\n", count, iterator->pid,iterator->command);
		       iterator = iterator->next;
                      
	    }
	    printf("Total background jobs are:%d\n", count);
}

/*change Directory*/
int changeDirectory(char* args[]){
    	if (args[1] == NULL) {
    		    chdir(getenv("HOME"));
    	      return 1;
    	}
	  //change the directory to the one specified
	   else{
	       	if (chdir(args[1]) == -1) {
		         	printf(" %s: no such directory\n", args[1]);
              return -1;
	      	}
   	}
	  return 0;
}

/* print the current directory */
void current_direct(){
	  char cwd[256];
    if (getcwd(cwd, sizeof(cwd)) != NULL)
            printf("SSI:%s >", cwd);
     else
           fprintf(stderr, "can't print current directory!");
}

int main(){
          char line[BUFFER_LEN];  //get command line
          char* argv[100];        //user command
          char* path= "/bin/";    //set path at bin
          char progpath[256];      //full file path

          while(1){
                   //print shell prompt and print shell
                 current_direct();
                 if(!fgets(line, BUFFER_LEN, stdin)){
                      break;
                }
                else {
                      size_t length = strlen(line);
                       if (line[length - 1] == '\n')
                          line[length - 1] = '\0';
                       char *token;                  //split command into separate strings
                       token = strtok(line," ");
                       int i=0;
                       while(token!=NULL && i< 100) {
                              argv[i]=token;
                              token = strtok(NULL," ");
                              i++;
                       }
                       argv[i]=NULL;     //set last value to NULL for execvp

                       // change directory
                       if (strcmp(argv[0],"cd")==0){
            	            	changeDirectory(argv);
                        }

                        strcpy(progpath, path);           //copy /bin/ to file path
                        strcat(progpath, argv[0]);            //add program to path

                        for(i=0; i<strlen(progpath); i++){    //delete newline
                            if(progpath[i]=='\n'){
                                progpath[i]='\0';
                            }
                        }
                        int pid= fork();              //fork child
                        if(pid==0){               //Child
                            execvp(progpath,argv);
                        }else{                    //Parent
                             wait(NULL);
                        }

                        if (strcmp(argv[0],"bg")==0)
            		                 bg(argv);
                        if (strcmp(argv[0],"bglist")==0)
            		                bglist();
                  }
             }
             return (0);
}

